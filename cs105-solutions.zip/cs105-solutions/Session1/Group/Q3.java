class Q3
{
    public static void main(String[] args)
    {
        double num = 64.;

        if (num > 0)
        {
            System.out.println("Num is positive.");
        }
        else if (num < 0)
        {
            System.out.println("Num is negative");
        }
        else
        {
            System.out.println("Num is invalid");
        }
    }
}