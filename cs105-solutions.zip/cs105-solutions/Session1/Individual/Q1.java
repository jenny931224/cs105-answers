class Q1
{
    public static void main(String[] args)
    {
        double a = 24.1;
        double b = 21.0;

        double sum = a + b;
        double dif = a - b;
        double product = a * b;
        double division = a / b;
        double mod = a % b;

        System.out.println("a: " + a);
        System.out.println("b: " + b);
        System.out.println("sum: " + sum);
        System.out.println("dif: " + dif);
        System.out.println("division: " + division);
        System.out.println("product: " + product);
        System.out.println("mod: " + mod);
    }
}