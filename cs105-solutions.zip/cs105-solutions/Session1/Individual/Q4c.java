class Q4c
{
    public static void main(String[] args)
    {
        for (int i = 1; i <= 7; i++)
        {
            for (int j = (7 - i); j > 0; j--)
            {
                System.out.print(("*"));
            }
            System.out.println();
        }
    }
}