class Q2
{
    public static void main(String[] args)
    {
        int num = 35;

        if (num % 2 == 0)
        {
            System.out.println(num + " is an even number.");
        }
        else
        {
            System.out.println(num + " is an odd number.");
        }
    }
}